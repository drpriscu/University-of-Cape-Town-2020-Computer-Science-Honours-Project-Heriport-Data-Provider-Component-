# Ashil Ramjee
# Bash Script to run the harvester component of the HERIPORT project
# Run as a Cron job

# Harvest files from ** in the file named dc.xml from the last date harvested.
# Date stored in the directory date in the text file date.txt
python2 listRecords.py -l http://rafiki1.cs.uct.ac.za/~alex/cgi-bin/BleekAndLloydOAIInterface.py -o dcXML/bl.xml -f $(head -n 1 date/date.txt)
python2 listRecords.py -l http://rafiki1.cs.uct.ac.za/~alex/cgi-bin/FHYAOAIInterface.py -o dcXML/fhya.xml -f $(head -n 1 date/date.txt)
python2 listRecords.py -l http://rafiki1.cs.uct.ac.za/~alex/cgi-bin/MetsemegologoloOAIInterface.py -o dcXML/metse.xml -f $(head -n 1 date/date.txt)

echo Metadata retrieved.

# Run dc2solr.py to perform the conversion
python2 dc2solr.py
echo Metadata converted to solr ready xml.

# Index xml files into solr
solr/bin/post -c Test2 solrXML/*.xml
echo Metadata indexed into solr.
rm solrXML/*

# Update date file
> date/date.txt
echo "$(date +'%Y-%m-%d')" >> date/date.txt
echo Dates updated
